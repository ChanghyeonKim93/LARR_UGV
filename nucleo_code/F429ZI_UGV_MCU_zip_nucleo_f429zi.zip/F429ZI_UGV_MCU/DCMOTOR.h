#ifndef DCMOTOR_H
#define DCMOTOR_H
 
#include "mbed.h"
#include "math.h"
#include "platform/mbed_thread.h"

#include "QEI/QEI.h" // Quadrature Encoder Interface

#include "Kalman_filter.h"

// in1  in2  pwm
//  0    0    x   brake
//  1    1    x   floating
//  1    0    1   right rotation
//  0    1    1   reverse rotation
//  1    0   PWM  right rot. pwm
//  0    1   PWM  reverse rot. pwm.

class DCMOTOR { 
public:    
    // Constructor
    DCMOTOR(PinName pin_pwm, PinName pin_in0, PinName pin_in1, 
            PinName pin_pulse_a, PinName pin_pulse_b, int ppr)
    : ppr_(ppr), inv_ppr_(1.0f/(float)ppr_), pwm_out_(pin_pwm), in0_(pin_in0), in1_(pin_in1), 
    encoder_(pin_pulse_a, pin_pulse_b, NC, ppr_, QEI::X4_ENCODING),
    kf_(0.07, 0.05, 0.03) {
        
        // control gains
        Kp_ = 0; Kd_ = 0; Ki_ = 0;
        err_prev_   = 0.0f;
        err_accum_  = 0.0f; 
        pwm_prev_   = 0.0f;
        
        w_measure_  = 0.0f;
        
        timer_.start();
        time_prev_ = (uint32_t)timer_.read_us();
    };
    
    
    void followDesiredAngularVelocity(float w_desired, float alpha_desired_ = 0.0f){
        // measure w from encoder
        this->measureAngularVelocity();
        
        // Kalman filtering.
        kf_.doFilter(w_measure_, dt_);
        w_est_     = kf_.getFiltered_w();
        alpha_est_ = kf_.getFiltered_a();
        
        // PID control        
        float err_p = w_desired - w_est_;
        float err_d = err_p - err_prev_;
        
        err_accum_ += err_p*dt_;
        if(err_accum_ >  0.2) err_accum_ =  0.2;
        if(err_accum_ < -0.2) err_accum_ = -0.2;
        float u = 0.1*(Kp_ * err_p + Kd_ * err_d/dt_ + Ki_ * err_accum_);
        
        pwm_value_ += u;
        float diff_pwm = pwm_value_ - pwm_prev_;
        if(diff_pwm > 0.5) pwm_value_ = pwm_prev_ + 0.5;
        if(diff_pwm < -0.5) pwm_value_ = pwm_prev_ - 0.5;
        
        this->setMotorRotation(pwm_value_);  
        
        err_prev_ = err_p;      
        pwm_prev_ = pwm_value_;
    };
    
    void  setControlGains(float kp, float kd, float ki){ Kp_ = kp; Kd_ = kd; Ki_ = ki; };
    float getAngularVelocity()     { return w_measure_; };
    float getAngularVelocity_Est() { return w_est_; };
    float getAngularAcceleration_Est() { return alpha_est_; };

private: // angular velocity calculations.
    void getTimeElapsed(){
        time_curr_ = (uint32_t)timer_.read_us();
        dt_        = (float)(time_curr_-time_prev_)/1000000.0f;
        time_prev_ = time_curr_;
    };
    void measureAngularVelocity(){
        getTimeElapsed();
        w_measure_ = (float)(encoder_.getPulsesReset()) * inv_ppr_ / dt_;
    };

private: // Motor PWM control methods
    void setMotorBreak(){ in0_ = false; in1_ = false; };
    void setMotorFloat(){ in0_ = true;  in1_ = true;  };
    void setMotorRotation(float pwm_signal) {
        float eps = 0.01; // dead-zone.
        if(pwm_signal >  1.0f) pwm_signal =  1.0f;
        if(pwm_signal < -1.0f) pwm_signal = -1.0f;
        if(pwm_signal > eps){ // Clock-wise Rotation (CW)
            in0_     = false; in1_ = true;
            pwm_out_ =  pwm_signal;
        }
        else if(pwm_signal < -eps){ // Counter Clock-wise Rotation (CCW)
            in0_     = true;  in1_ = false;
            pwm_out_ = -pwm_signal;
        }
        else setMotorFloat();    
    };
    
// Private members
private:
    // Motor PWM & direction signals
    PwmOut     pwm_out_;
    DigitalOut in0_;
    DigitalOut in1_;
    
    // Quadrature encoder
    // Use X4 encoding. --> QEI wheel(p29, p30, NC, 624, QEI::X4_ENCODING);
    // Use X2 encoding by default.--> QEI wheel (p29, p30, NC, 624);
    QEI encoder_;
    float w_measure_;
    
    // Kalman filter for w and alpha
    KalmanFilter kf_;
    float w_est_;
    float alpha_est_;
    
    // Parameters
    int ppr_;
    float inv_ppr_; // 1 / (ppr_ * gear_ratio)
    
    // PID controller
    float Kp_;
    float Kd_;
    float Ki_;
    float err_prev_;
    float err_accum_;
    
    float pwm_value_;
    float pwm_prev_;
        
    // Timer to know the elapsed time.
    Timer timer_;    
    uint32_t time_prev_;
    uint32_t time_curr_;
    float dt_;
};


#endif