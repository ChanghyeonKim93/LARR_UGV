#ifndef DCMOTOR_H
#define DCMOTOR_H
 
#include "mbed.h"
#include "math.h"
#include "platform/mbed_thread.h"


#include "QEI/QEI.h" // Quadrature Encoder Interface

// in1  in2  pwm
//  0    0    x   brake
//  1    1    x   floating
//  1    0    1   right rotation
//  0    1    1   reverse rotation
//  1    0   PWM  right rot. pwm
//  0    1   PWM  reverse rot. pwm.

class DCMOTOR { 
public:
    // Rotation direction (CW, CCW)
    typedef enum Direction {
                //      in0  in1  pwm
        CW,     // 0:    1    0   PWM // right rotation... not used.
        CCW,    // 1:    0    1   PWM // reverse rotation
        Break,  // 2:    0    0    x
        Float   // 3:    1    1    x  
    } Direction;
    
    // Constructor
    DCMOTOR(PinName pin_pwm, PinName pin_in0, PinName pin_in1, PinName pin_pulse_a, PinName pin_pulse_b, int pulse_per_rev)
    : pulse_per_rev_(pulse_per_rev), pwm_out_(pin_pwm), in0_(pin_in0), in1_(pin_in1), encoder_(pin_pulse_a, pin_pulse_b, NC, pulse_per_rev_) {
               
        Kp_ = 0;
        Kd_ = 0;
        Ki_ = 0;
        e_prev_  = 0.0f;
        e_accum_ = 0.0f;    
        pwm_prev_ = 0.0f;
        
        pulses_to_wheel_rev_ = 1.0f/(float)pulse_per_rev_;
        
        timer_.start();
    };
    
    void setMotorBreak(){    
        // Break
        in0_ = false;
        in1_ = false;
    };
    
    void setMotorFloat(){
        // Float
        in0_ = true;
        in1_ = true;
    };
    
    void setMotorRotation(float pwm_signal) {
        float eps = 0.01;
        if(pwm_signal > 1.0f)  pwm_signal = 1.0f;
        if(pwm_signal < -1.0f) pwm_signal = -1.0f;
        if(pwm_signal > eps){
            // Clock-wise Rotation (CW)
            in0_     = false;
            in1_     = true;
            pwm_out_ = pwm_signal;
        }
        else if(pwm_signal < -eps){
            // Counter Clock-wise Rotation (CCW)
            in0_     = true;
            in1_     = false;
            pwm_out_ = -pwm_signal;
        }
        else{
            setMotorFloat();    
        }
    };
    
    
    int getAngularRotation(){
        return encoder_.getPulsesReset();
    };
    
    void setPIDControl(float w_curr, float w_desired){
        float e_p = (w_desired - w_curr);
        float e_d = e_p - e_prev_;
        
        e_accum_ += e_p*0.05;
        if(e_accum_ >  0.2) e_accum_ =  0.2;
        if(e_accum_ < -0.2) e_accum_ = -0.2;
        
        float pwm_signal = 0.1*w_desired + (Kp_ * e_p + Kd_ * e_d + Ki_ * e_accum_);
        
        float diff_pwm = pwm_signal - pwm_prev_;
        if(diff_pwm > 0.03) pwm_signal = pwm_prev_ + 0.03;
        if(diff_pwm < -0.03) pwm_signal = pwm_prev_ - 0.03;
        
        setMotorRotation(pwm_signal);  
        
        e_prev_ = e_p;      
        pwm_prev_ = pwm_signal;
    };
    
    void setControlGains(float kp, float kd, float ki){
        Kp_ = kp;
        Kd_ = kd;
        Ki_ = ki;  
    };
    
private:
    PwmOut     pwm_out_;
    DigitalOut in0_;
    DigitalOut in1_;
    QEI encoder_;
    // Use X4 encoding. --> QEI wheel(p29, p30, NC, 624, QEI::X4_ENCODING);
    // Use X2 encoding by default.--> QEI wheel (p29, p30, NC, 624);
        
    
    // Parameters
    int pulse_per_rev_;
    float pulses_to_wheel_rev_; // 1 / (pulse_per_rev_ * gear_ratio)
    
    // PID controller
    float Kp_;
    float Kd_;
    float Ki_;
    float e_prev_;
    float e_accum_;
    
    float pwm_prev_;
        
    // Timer to know how much time elapses.
    Timer timer_;    
};


#endif