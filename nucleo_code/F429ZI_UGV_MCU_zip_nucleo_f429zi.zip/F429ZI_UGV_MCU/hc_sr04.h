#ifndef HCSR04_H
#define HCSR04_H
 
#include "mbed.h"
#include "math.h"
#include "platform/mbed_thread.h"

// sonic speed : 340.1 m/s 
// 340.1 m/s = 34010 cm/s
// distance (in [cm]) for a microsecond: 0.00294 cm/us (== 58.8 scaler)
// 3.5 m : ~ 10 ms
// range: 0.1 ~ 3.5 m

class HCSR04_SONAR{
public:
    HCSR04_SONAR(PinName trg, PinName e0, PinName e1, PinName e2) 
    : pin_trigger_(trg), pin_echo0_(e0), pin_echo1_(e1), pin_echo2_(e2){
        // timer_.reset();
        // measure actual software polling timer delays
        // delay used later in time correction
        // start timer
        //timer_.start();
        //while(pin_echo_ == 2) {};
        // stop timer
        //timer_.stop();
        //read timer
        correction_ = 2; // 2 us
        pc.printf("Approximate software overhead timer delay is %d uS\n\r",correction_); 
        
        pin_echo0_.rise(callback(this, &HCSR04_SONAR::startEcho0)); // start echo0
        pin_echo0_.fall(callback(this, &HCSR04_SONAR::endEcho0)); // end echo0
        
        pin_echo1_.rise(callback(this, &HCSR04_SONAR::startEcho1)); // start echo1
        pin_echo1_.fall(callback(this, &HCSR04_SONAR::endEcho1)); // end echo1
        
        pin_echo2_.rise(callback(this, &HCSR04_SONAR::startEcho2)); // start echo2
        pin_echo2_.fall(callback(this, &HCSR04_SONAR::endEcho2)); // end echo2
    };
    
    void measureAll(){
        timer_.reset();
        timer_.start();
        pin_trigger_ = 1;
        wait_us(10.0); // 10 us wait.
        pin_trigger_ = 0;
        flag_done_[0] = 0; flag_done_[1] = 0; flag_done_[2] = 0;
    };    
    
    void getDistances(int* dist){
        dist[0] = distance_[0]; // cm
        dist[1] = distance_[1]; // cm
        dist[2] = distance_[2]; // cm
    };
    
private:
        void startEcho0(){
            time_rise_[0] = timer_.read_us();
        };
        void endEcho0(){
            time_fall_[0] = timer_.read_us();
            distance_[0] = (time_fall_[0]-time_rise_[0]-correction_)/58.0;
            flag_done_[0] = 1;
            if(flag_done_[0] &&flag_done_[1] && flag_done_[2]) timer_.stop();
        };
        
        void startEcho1(){
            time_rise_[1] = timer_.read_us();
        };
        void endEcho1(){
            time_fall_[1] = timer_.read_us();
            distance_[1] = (time_fall_[1]-time_rise_[1]-correction_)/58.0;
            flag_done_[1] = 1;
            if(flag_done_[0] &&flag_done_[1] && flag_done_[2]) timer_.stop();
        };
        
        void startEcho2(){
            time_rise_[2] = timer_.read_us();
        };
        void endEcho2(){
            time_fall_[2] = timer_.read_us();
            distance_[2] = (time_fall_[2]-time_rise_[2]-correction_)/58.0;
            flag_done_[2] = 1;
            if(flag_done_[0] &&flag_done_[1] && flag_done_[2]) timer_.stop();
        }; 
        
private:
    DigitalOut pin_trigger_;
    
    InterruptIn pin_echo0_;
    InterruptIn pin_echo1_;
    InterruptIn pin_echo2_;
    
    int time_rise_[3];
    int time_fall_[3];
    int distance_[3];
    int flag_done_[3];
    int correction_;      
    
    Timer timer_;  
};

#endif