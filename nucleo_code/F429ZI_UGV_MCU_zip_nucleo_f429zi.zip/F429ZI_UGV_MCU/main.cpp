    // TODO: Consecutively read data (not only 6 bytes step size)
    // TODO: Thread queue-based data read. ISR only pushes the 'read event' to worker thread.
    // TODO: double encoders! https://m.blog.naver.com/alexpark0922/221638739710
    
/* mbed Microcontroller Library
 * Copyright (c) 2019 ARM Limited
 * SPDX-License-Identifier: Apache-2.0
 */

#include "mbed.h"
#include "platform/mbed_thread.h"

// Serial related
Serial pc(USBTX, USBRX);

#include "EthernetInterface.h"  // ref. https://os.mbed.com/questions/79209/EthernetInterface-MBED-OS-56-static-IP/
#include "TCPSocket.h"

#include "MPU9250.h" // IMU, https://os.mbed.com/users/manitou/code/mpu9250//file/0158e4d78423/main.cpp/
#include "DCMOTOR.h" // Motor with quadrature encoder.


#define PULSES_PER_MOTOR_REV  19
#define GEAR_RATIO            49
#define ENCODER_SCALER        4
#define PULSES_PER_REV        (PULSES_PER_MOTOR_REV*GEAR_RATIO*ENCODER_SCALER)

// 5 pins are needed for motor + encoder.
#define PIN_PWM_MOTOR0      PC_8  // motor pwm signal;
#define PIN_IN0_MOTOR0      PA_5  // motor direction 1;
#define PIN_IN1_MOTOR0      PA_6  // motor direction 2;
#define PIN_PULSE_A_MOTOR0  PD_14  // Quadrature Encoder pulse a ; int 14
#define PIN_PULSE_B_MOTOR0  PD_15  // Quadrature Encoder pulse b ; int 15

#define PIN_PWM_MOTOR1      PC_9  // motor pwm signal;
#define PIN_IN0_MOTOR1      PA_15  // motor direction 1;
#define PIN_IN1_MOTOR1      PC_7 // motor direction 2;
#define PIN_PULSE_B_MOTOR1  PB_3  // Quadrature Encoder pulse a; int 3
#define PIN_PULSE_A_MOTOR1  PA_4 // Quadrature Encoder pulse b; int 4


// IMU interrupt pin
#define PIN_IMU_INTTERRUPT  PC_6 //int 6


// Sonar sensors
#define PIN_SONAR_TRIGGER PB_2
#define PIN_SONAR_ECHO_2  PD_13 //int 13 
#define PIN_SONAR_ECHO_1  PE_7 //int 7
#define PIN_SONAR_ECHO_0  PG_9 //int 8


// STATUS TO BE SENT TO THE COMPUTER
#define STATE_IMU      0b00000001
#define STATE_CAMERA   0b00000010
#define STATE_CONTROL  0b00000100
#define STATE_ENCODER  0b00001000
#define STATE_SONAR    0b00010000

// Network interface
#define SERVER_IP  "192.168.1.15"
#define SERVER_PORT 1312
#define MCU_IP     "192.168.1.9"
#define GATEWAY    "192.168.1.0" // not used....
#define MASK       "255.255.255.0"

typedef union USHORT_UNION_{
    uint16_t ushort_;
    uint8_t bytes_[2];
} USHORT_UNION;

typedef union UINT_UNION_{
    uint32_t uint_;
    uint8_t bytes_[4];
} UINT_UNION;

typedef union FLOAT_UNION_{
    float float_;
    char bytes_[4];   
} FLOAT_UNION;


#include "hc_sr04.h"

// Motor related
DCMOTOR motor0(PIN_PWM_MOTOR0, PIN_IN0_MOTOR0, PIN_IN1_MOTOR0, PIN_PULSE_A_MOTOR0, PIN_PULSE_B_MOTOR0, PULSES_PER_REV);
DCMOTOR motor1(PIN_PWM_MOTOR1, PIN_IN0_MOTOR1, PIN_IN1_MOTOR1, PIN_PULSE_A_MOTOR1, PIN_PULSE_B_MOTOR1, PULSES_PER_REV);

// Sonar related
HCSR04_SONAR sonar(PIN_SONAR_TRIGGER, PIN_SONAR_ECHO_0, PIN_SONAR_ECHO_1, PIN_SONAR_ECHO_2);
Ticker sonar_ticker;

// Ethernet related
EthernetInterface eth;
TCPSocket client_socket;

// IMU related
MPU9250 mpu9250;
InterruptIn int_imu(PIN_IMU_INTTERRUPT);

// Set event queue and worker thread
Thread thread_poll(osPriorityRealtime); // polling all interrupt signals. https://os.mbed.com/docs/mbed-os/v6.10/apis/thread.html
EventQueue equeue(128 * EVENTS_EVENT_SIZE);

volatile bool FLAG_IMU_NEWDATA      = false;
volatile bool FLAG_DO_ETHERNET_SEND = false;

void workISRUserContext_IMU(){ // this code will run in the user context.
    mpu9250.readByte(MPU9250_ADDRESS, INT_STATUS);  //? need this with ISR
    mpu9250.readAccelData(accelCount, accel_raw);  // Read the x/y/z adc values
    mpu9250.readGyroData(gyroCount, gyro_raw);  // Read the x/y/z adc values
};

void flagISR_IMU(){
    FLAG_IMU_NEWDATA = true;
    equeue.call(workISRUserContext_IMU); 
}; // ISR function for IMU


// Timer to know how much time elapses.
Timer timer;

int main()
{
    // Serial port initialization.
    pc.baud(115200);        
    
    // Start the event queue
    thread_poll.start(callback(&equeue, &EventQueue::dispatch_forever));
    pc.printf("Starting event queue in context %p\r\n", ThisThread::get_id());
        
    int_imu.rise(flagISR_IMU);
    
    // Ethernet initialization // ref. https://os.mbed.com/questions/79209/EthernetInterface-MBED-OS-56-static-IP/    
    int constat = eth.set_network(MCU_IP,MASK,GATEWAY);  // use static IP address, netmask, gateway
    pc.printf("set MCU IP status: %i \r\n",constat);
    constat = eth.connect();
    pc.printf("connect status: %i \r\n",constat);
    const char *ip = eth.get_ip_address();
    const char *mac = eth.get_mac_address();
    printf("MCU IP address is:  %s\n\r", ip ? ip : "No IP");
    printf("MCU MAC address is: %s\n\r", mac ? mac : "No MAC");
    client_socket.open(&eth);
    
    // Timer starts.
    timer.start();
    uint32_t time_curr;
    uint32_t time_prev;
    
    USHORT_UNION tsec;
    UINT_UNION   tusec;
    
    // IMU initialization (I2C Setup)
    i2c.frequency(400000);  // use fast (400 kHz) I2C   
    uint8_t whoami = mpu9250.readByte(MPU9250_ADDRESS, WHO_AM_I_MPU9250);  // Read WHO_AM_I register for MPU-9250
    pc.printf("I AM 0x%x\n\r", whoami);
    
    if (whoami == 0x71) { // WHO_AM_I should always be 0x68
        pc.printf("MPU9250 is online...\n\r");
        mpu9250.resetMPU9250(); // Reset registers to default in preparation for device calibration
        mpu9250.calibrateMPU9250(gyroBias, accelBias); // Calibrate gyro and accelerometers, load biases in bias registers
        wait(1);
        mpu9250.initMPU9250();
        pc.printf("MPU9250 initialized for active data mode....\n\r"); // Initialize device for active mode read of acclerometer, gyroscope, and temperature
        mpu9250.initAK8963(magCalibration);
        pc.printf("AK8963 initialized for active data mode....\n\r"); // Initialize device for active mode read of magnetometer
        pc.printf("Accelerometer full-scale range = %f  g\n\r", 2.0f*(float)(1<<Ascale));
        pc.printf("Gyroscope full-scale range = %f  deg/s\n\r", 250.0f*(float)(1<<Gscale));
        if(Mscale == 0) pc.printf("Magnetometer resolution = 14  bits\n\r");
        if(Mscale == 1) pc.printf("Magnetometer resolution = 16  bits\n\r");
        if(Mmode == 2) pc.printf("Magnetometer ODR = 8 Hz\n\r");
        if(Mmode == 6) pc.printf("Magnetometer ODR = 100 Hz\n\r");
        wait(1);
    } else {
        pc.printf("Could not connect to MPU9250: \n\r");
        pc.printf("%#x \n",  whoami); 
        while(1) ; // Loop forever if communication doesn't happen
    }
    
    mpu9250.getAres(); // Get accelerometer sensitivity
    mpu9250.getGres(); // Get gyro sensitivity
    mpu9250.getMres(); // Get magnetometer sensitivity
    pc.printf("Accelerometer sensitivity is %f LSB/g \n\r", 1.0f/aRes);
    pc.printf("Gyroscope sensitivity is %f LSB/deg/s \n\r", 1.0f/gRes);
    pc.printf("Magnetometer sensitivity is %f LSB/G \n\r", 1.0f/mRes);
    // magbias[0] = +470.;  // User environmental x-axis correction in milliGauss, should be automatically calculated
    // magbias[1] = +120.;  // User environmental x-axis correction in milliGauss
    // magbias[2] = +125.;  // User environmental x-axis correction in milliGauss
    
    // Initialize Sonar
    sonar_ticker.attach(callback(&sonar, &HCSR04_SONAR::measureAll), 0.05); // interval should be larger than 0.02 s (50 Hz)
    
    
    //
    char sbuffer[64]; // 64 bytes sending buffer
    char rbuffer[64]; // 64 bytes receiving buffer
    
    FLOAT_UNION w_left;  w_left.float_ = 0.0f;
    FLOAT_UNION w_right; w_right.float_ = 0.0f;    
    FLOAT_UNION w_left_desired;  w_left_desired.float_  = 0.0f;
    FLOAT_UNION w_right_desired; w_right_desired.float_ = 0.0f;
    FLOAT_UNION kp,kd,ki;
    
    USHORT_UNION sonar_dist0; sonar_dist0.ushort_ = 0;
    USHORT_UNION sonar_dist1; sonar_dist1.ushort_ = 0;
    USHORT_UNION sonar_dist2; sonar_dist2.ushort_ = 0;
    
    kp.float_ = 0;
    kd.float_ = 0;
    ki.float_ = 0;    
    
    int count_control_loop = 0;    
    int count_sonar_loop   = 0;
    while (1) {
        // Whenever new IMU data is on, send data on the ethernet (200 Hz)
        FLAG_DO_ETHERNET_SEND = FLAG_IMU_NEWDATA;
        if(FLAG_DO_ETHERNET_SEND) {
            // Request to the TCP/IP server (PC)                       
            int eth_conn = client_socket.connect(SERVER_IP, SERVER_PORT);
            
            // Connection OK.
            if((eth_conn == NSAPI_ERROR_OK) 
            || (eth_conn == NSAPI_ERROR_IS_CONNECTED)){
                // OFF all flags
                FLAG_DO_ETHERNET_SEND = false;
                FLAG_IMU_NEWDATA      = false;
                
                // Current time
                time_curr    = (uint32_t)timer.read_us();
                tsec.ushort_ = (uint16_t)(time_curr/1000000);
                tusec.uint_  = (uint32_t)(time_curr-((uint32_t)tsec.ushort_)*1000000);
                
                // STATE
                unsigned char STATE_MCU_TO_PC = 0;
                STATE_MCU_TO_PC |= STATE_IMU;
                                
                // fill out send buffer
                sbuffer[0]   = accel_raw[0]; // High acc x
                sbuffer[1]   = accel_raw[1]; // Low acc x
                sbuffer[2]   = accel_raw[2]; // High acc y
                sbuffer[3]   = accel_raw[3]; // low acc y
                sbuffer[4]   = accel_raw[4]; // High acc z
                sbuffer[5]   = accel_raw[5]; // low acc z
                sbuffer[6]   = gyro_raw[0];   // High gy x
                sbuffer[7]   = gyro_raw[1];   // Low gy x
                sbuffer[8]   = gyro_raw[2];   // High gy y
                sbuffer[9]   = gyro_raw[3];   // low gy y
                sbuffer[10]  = gyro_raw[4];   // High gy z
                sbuffer[11]  = gyro_raw[5];   // low gy z
                
                sbuffer[12]  = w_left.bytes_[0]; // encoder left lowest
                sbuffer[13]  = w_left.bytes_[1]; // encoder left low
                sbuffer[14]  = w_left.bytes_[2]; // encoder left high
                sbuffer[15]  = w_left.bytes_[3]; // encoder left highest
                
                sbuffer[16]  = w_right.bytes_[0]; // encoder right lowest
                sbuffer[17]  = w_right.bytes_[1]; // encoder right low
                sbuffer[18]  = w_right.bytes_[2]; // encoder right high
                sbuffer[19]  = w_right.bytes_[3]; // encoder right highest
                
                sbuffer[20]  = tsec.bytes_[0];  // time (second part, low)
                sbuffer[21]  = tsec.bytes_[1];  // time (second part, high)
                
                sbuffer[22]  = tusec.bytes_[0]; // time (microsecond part, lowest)
                sbuffer[23]  = tusec.bytes_[1]; // time (microsecond part, low)
                sbuffer[24]  = tusec.bytes_[2]; // time (microsecond part, high)
                sbuffer[25]  = tusec.bytes_[3]; // time (microsecond part, highest)
                              
                sbuffer[26]  = STATE_MCU_TO_PC;
                
                sbuffer[27]  = sonar_dist0.bytes_[0];
                sbuffer[28]  = sonar_dist0.bytes_[1];
                sbuffer[29]  = sonar_dist1.bytes_[0];
                sbuffer[30]  = sonar_dist1.bytes_[1];
                sbuffer[31]  = sonar_dist2.bytes_[0];
                sbuffer[32]  = sonar_dist2.bytes_[1];
                
                
                // [SEND ETERNET] data to PC
                int scount = client_socket.send(sbuffer, 33 + 1); // 10 us per 1 byte
                if(NSAPI_ERROR_NO_CONNECTION == scount) {
                    client_socket.close();
                    client_socket.open(&eth); // reopen the socket.
                    continue;
                }
                
                ++count_control_loop;
                ++count_sonar_loop;
                
                // [RECV ETHERNET] data from PC
                int rcount = client_socket.recv(rbuffer, sizeof rbuffer); // 16 words 160 us
                if(rcount > 0){ // if there is a signal, (control signal...?)
                    w_left_desired.bytes_[0] = rbuffer[0];
                    w_left_desired.bytes_[1] = rbuffer[1];
                    w_left_desired.bytes_[2] = rbuffer[2];
                    w_left_desired.bytes_[3] = rbuffer[3];
                    
                    w_right_desired.bytes_[0] = rbuffer[0];
                    w_right_desired.bytes_[1] = rbuffer[1];
                    w_right_desired.bytes_[2] = rbuffer[2];
                    w_right_desired.bytes_[3] = rbuffer[3];
                    
                    kp.bytes_[0] = rbuffer[4];
                    kp.bytes_[1] = rbuffer[5];
                    kp.bytes_[2] = rbuffer[6];
                    kp.bytes_[3] = rbuffer[7];
                    
                    kd.bytes_[0] = rbuffer[8];
                    kd.bytes_[1] = rbuffer[9];
                    kd.bytes_[2] = rbuffer[10];
                    kd.bytes_[3] = rbuffer[11];
                    
                    ki.bytes_[0] = rbuffer[12];
                    ki.bytes_[1] = rbuffer[13];
                    ki.bytes_[2] = rbuffer[14];
                    ki.bytes_[3] = rbuffer[15];
                    
                    // 100 Hz motor control
                    if(count_control_loop > 2){ 
                        // Calculate encoder                        
                        motor0.setControlGains(kp.float_, kd.float_, ki.float_);
                        motor0.followDesiredAngularVelocity(w_left_desired.float_, 0.0f);
                        
                        motor1.setControlGains(kp.float_, kd.float_, ki.float_);
                        motor1.followDesiredAngularVelocity(w_left_desired.float_, 0.0f);
                        
                        w_left.float_  = motor0.getAngularVelocity();
                        w_right.float_ = motor1.getAngularVelocity();
                        
                        pc.printf("wd:%0.2f,wl:%0.2f,wr:%0.2f\r\n", w_left_desired.float_, w_left.float_,w_right.float_);
                        
                        int dist[3];
                        sonar.getDistances(dist);
                        sonar_dist0.ushort_ = dist[0];
                        sonar_dist1.ushort_ = dist[1];
                        sonar_dist2.ushort_ = dist[2];
                        pc.printf("%d %d %d\r\n", dist[0],dist[1],dist[2]);
                        
                        count_control_loop = 0;
                    } // end if (control phase)
                    
                    // 20 Hz sonar measuring
                    if(count_sonar_loop > 9){
                        //int dist[3];
                        //sonar.getDistances(dist);
                        //pc.printf("%d %d %d\r\n", dist[0],dist[1],dist[2]);
                        
                        count_sonar_loop = 0;
                    }
                } // end if (recv buffer is not empty)               
            }
        }   
    }
}



/*
while(1) {
        static int readycnt=0;
        // If intPin goes high, all data registers have new data
 
#if USE_ISR
        if(newData) {
            newData=false;
            mpu9250.readByte(MPU9250_ADDRESS, INT_STATUS);  //? need this with ISR
#else
        if(mpu9250.readByte(MPU9250_ADDRESS, INT_STATUS) & 0x01) {  // On interrupt, check if data ready interrupt
#endif
            readycnt++;
            mpu9250.readAccelData(accelCount);  // Read the x/y/z adc values
            // Now we'll calculate the accleration value into actual g's
            ax = (float)accelCount[0]*aRes - accelBias[0];  // get actual g value, this depends on scale being set
            ay = (float)accelCount[1]*aRes - accelBias[1];
            az = (float)accelCount[2]*aRes - accelBias[2];
 
            mpu9250.readGyroData(gyroCount);  // Read the x/y/z adc values
            // Calculate the gyro value into actual degrees per second
            gx = (float)gyroCount[0]*gRes - gyroBias[0];  // get actual gyro value, this depends on scale being set
            gy = (float)gyroCount[1]*gRes - gyroBias[1];
            gz = (float)gyroCount[2]*gRes - gyroBias[2];
 
            mpu9250.readMagData(magCount);  // Read the x/y/z adc values
            // Calculate the magnetometer values in milliGauss
            // Include factory calibration per data sheet and user environmental corrections
            mx = (float)magCount[0]*mRes*magCalibration[0] - magbias[0];  // get actual magnetometer value, this depends on scale being set
            my = (float)magCount[1]*mRes*magCalibration[1] - magbias[1];
            mz = (float)magCount[2]*mRes*magCalibration[2] - magbias[2];
        }
 
        Now = t.read_us();
        deltat = (float)((Now - lastUpdate)/1000000.0f) ; // set integration time by time elapsed since last filter update
        lastUpdate = Now;
 
        sum += deltat;
        sumCount++;
 
//    if(lastUpdate - firstUpdate > 10000000.0f) {
//     beta = 0.04;  // decrease filter gain after stabilized
//     zeta = 0.015; // increasey bias drift gain after stabilized
//   }
 
        // Pass gyro rate as rad/s
        uint32_t us = t.read_us();
        mpu9250.MadgwickQuaternionUpdate(ax, ay, az, gx*PI/180.0f, gy*PI/180.0f, gz*PI/180.0f,  my,  mx, mz);
        us = t.read_us()-us;
// mpu9250.MahonyQuaternionUpdate(ax, ay, az, gx*PI/180.0f, gy*PI/180.0f, gz*PI/180.0f, my, mx, mz);
 
        // Serial print and/or display at 0.5 s rate independent of data rates
        delt_t = t.read_ms() - count;
        if (delt_t > 500) { // update LCD once per half-second independent of read rate
            pc.printf("readycnt %d us %d\n",readycnt,us);
            readycnt=0;
            pc.printf("ax = %f", 1000*ax);
            pc.printf(" ay = %f", 1000*ay);
            pc.printf(" az = %f  mg\n\r", 1000*az);
 
            pc.printf("gx = %f", gx);
            pc.printf(" gy = %f", gy);
            pc.printf(" gz = %f  deg/s\n\r", gz);
 
            pc.printf("gx = %f", mx);
            pc.printf(" gy = %f", my);
            pc.printf(" gz = %f  mG\n\r", mz);
 
            tempCount = mpu9250.readTempData();  // Read the adc values
            temperature = ((float) tempCount) / 333.87f + 21.0f; // Temperature in degrees Centigrade
            pc.printf("temperature = %f  C\n\r", temperature);
 
            pc.printf("q0 = %f\n\r", q[0]);
            pc.printf("q1 = %f\n\r", q[1]);
            pc.printf("q2 = %f\n\r", q[2]);
            pc.printf("q3 = %f\n\r", q[3]);
 
 
 
            // Define output variables from updated quaternion---these are Tait-Bryan angles, commonly used in aircraft orientation.
            // In this coordinate system, the positive z-axis is down toward Earth.
            // Yaw is the angle between Sensor x-axis and Earth magnetic North (or true North if corrected for local declination, looking down on the sensor positive yaw is counterclockwise.
            // Pitch is angle between sensor x-axis and Earth ground plane, toward the Earth is positive, up toward the sky is negative.
            // Roll is angle between sensor y-axis and Earth ground plane, y-axis up is positive roll.
            // These arise from the definition of the homogeneous rotation matrix constructed from quaternions.
            // Tait-Bryan angles as well as Euler angles are non-commutative; that is, the get the correct orientation the rotations must be
            // applied in the correct order which for this configuration is yaw, pitch, and then roll.
            // For more see http://en.wikipedia.org/wiki/Conversion_between_quaternions_and_Euler_angles which has additional links.
            yaw   = atan2(2.0f * (q[1] * q[2] + q[0] * q[3]), q[0] * q[0] + q[1] * q[1] - q[2] * q[2] - q[3] * q[3]);
            pitch = -asin(2.0f * (q[1] * q[3] - q[0] * q[2]));
            roll  = atan2(2.0f * (q[0] * q[1] + q[2] * q[3]), q[0] * q[0] - q[1] * q[1] - q[2] * q[2] + q[3] * q[3]);
            pitch *= 180.0f / PI;
            yaw   *= 180.0f / PI;
            yaw   -= 13.8f; // Declination at Danville, California is 13 degrees 48 minutes and 47 seconds on 2014-04-04
            roll  *= 180.0f / PI;
 
            pc.printf("Yaw, Pitch, Roll: %f %f %f\n\r", yaw, pitch, roll);
            pc.printf("average rate = %f\n\r", (float) sumCount/sum);
 
            myled= !myled;
            count = t.read_ms();
            sum = 0;
            sumCount = 0;
        }
    }
*/